﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_registro_bibliotecario
{
    class _Libro
    {
        public string Libro { get; set; }
        public string Autor { get; set; }
        public string Ubicacion { get; set; }
        public string Cantidad { get; set; }
    }
}
